create procedure prepare_dept()
  BEGIN 
DECLARE i INT DEFAULT 1; 
WHILE i <= 40 DO 
INSERT INTO department (name) 
VALUES (CONCAT('Департамент', i)); 
SET i = i + 1; 
END WHILE; 
END;

