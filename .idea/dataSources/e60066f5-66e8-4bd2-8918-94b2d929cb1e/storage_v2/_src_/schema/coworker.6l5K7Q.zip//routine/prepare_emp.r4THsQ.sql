create procedure prepare_emp()
  BEGIN 
DECLARE i INT DEFAULT 1; 
WHILE i <= 500 DO 
INSERT INTO employee (department_id, name, salary, chief_id) 
VALUES (RAND() * (40 - 1) + 1, CONCAT('Сотрудник', i), RAND() * (10000 - 500) + 500, RAND() * (40 - 1) + 1); 
SET i = i + 1; 
END WHILE;
WHILE i <= 600 DO 
INSERT INTO employee (department_id, name, salary, chief_id) 
VALUES (RAND() * (40 - 1) + 1, CONCAT('Сотрудник', i), RAND() * (10000 - 500) + 500, NULL); 
SET i = i + 1; 
END WHILE;
END;

